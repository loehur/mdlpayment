<?php

class Public_Variables
{
    public $BASE_URL = '/web/payment/';
    public $ASSETS_URL = '/web/payment/assets/';
    public $CLASS = "";
    public $username = "081834695669";
    public $db_pass = '';
    public $apiKey = '54521d5ss2364sdrr21546ss5';
    public $prepaid_url = "https://pranetmobile.id/";
    public $postpaid_url = "https://gadgetonline.net/";
    public $margin_prepaid1 = 200;
    public $margin_prepaid2 = 500;
    public $admin_postpaid1 = 0;
    public $admin_postpaid2 = 1000;
    public $login_key = "Qjtc9Q==";
    public $valid_users = array(
        0 => "081268098300",
        1 => "082352616290",
        2 => "082288571000",
        3 => "mdl-pn",
        4 => "mdl-su",
        5 => "mdl-rm",
        6 => "mdl-rw",
        7 => "mdl-ks",
        8 => "mdl-tg"
    );
    public $token_wa = "M2tCJhb_mcr5tHFo5r4B";
}
