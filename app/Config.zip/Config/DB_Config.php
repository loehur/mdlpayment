<?php

class DB_Config
{
    public $db_host = 'localhost';
    public $db_user = 'root';
    public $db_name = 'payment';
    public $controller = 'Home';
}
